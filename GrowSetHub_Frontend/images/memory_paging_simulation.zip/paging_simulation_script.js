
document.addEventListener("DOMContentLoaded", () => {
  const logicalAddressDisplay = document.getElementById("logicalAddress");
  const tlbEntries = document.getElementById("tlb-entries");
  const pageTable = document.getElementById("page-table");
  const ramFrames = document.getElementById("ram-frames");

  const pageTableMap = {
    0: 2,
    1: 3,
    2: 1,
    3: 0,
  };
  const frameData = {
    0: "Page 3",
    1: "Page 2",
    2: "Page 0",
    3: "Page 1",
  };

  function updatePageTable() {
    pageTable.innerHTML = "";
    Object.entries(pageTableMap).forEach(([page, frame]) => {
      const li = document.createElement("li");
      li.textContent = `Page ${page} → Frame ${frame}`;
      pageTable.appendChild(li);
    });
  }

  function updateRam() {
    ramFrames.innerHTML = "";
    for (let i = 0; i < 4; i++) {
      const li = document.createElement("li");
      li.textContent = `Frame ${i}: ${frameData[i] || "Empty"}`;
      ramFrames.appendChild(li);
    }
  }

  let tlb = [];

  function updateTLB() {
    tlbEntries.innerHTML = "";
    for (let entry of tlb) {
      const li = document.createElement("li");
      li.textContent = `Page ${entry.page} → Frame ${entry.frame}`;
      tlbEntries.appendChild(li);
    }
    while (tlb.length < 2) {
      const li = document.createElement("li");
      li.textContent = "Empty";
      tlbEntries.appendChild(li);
    }
  }

  function simulateAccess() {
    const logicalAddress = Math.floor(Math.random() * 16); // 4 pages, 4 blocks per page
    const page = logicalAddress >> 2;
    const offset = logicalAddress & 0b11;
    const binaryAddr = "0b" + logicalAddress.toString(2).padStart(4, "0");

    logicalAddressDisplay.textContent = `${binaryAddr} (Page ${page}, Offset ${offset})`;

    const tlbHit = tlb.find((entry) => entry.page === page);
    let frame;
    if (tlbHit) {
      frame = tlbHit.frame;
    } else {
      frame = pageTableMap[page];
      if (tlb.length >= 2) tlb.shift();
      tlb.push({ page, frame });
    }

    document.querySelectorAll("#ram-frames li").forEach((el) => {
      el.classList.remove("highlight");
    });
    const ramLi = document.querySelector(`#ram-frames li:nth-child(${frame + 1})`);
    if (ramLi) ramLi.classList.add("highlight");

    updateTLB();
  }

  document.getElementById("start").addEventListener("click", simulateAccess);
  document.getElementById("reset").addEventListener("click", () => {
    tlb = [];
    updateTLB();
    logicalAddressDisplay.textContent = "0x000";
    document.querySelectorAll("#ram-frames li").forEach((el) => el.classList.remove("highlight"));
  });

  updatePageTable();
  updateRam();
  updateTLB();
});
